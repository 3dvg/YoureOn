
using System;
using System.Text;
using System.Collections.Generic;
using NHibernate;
using NHibernate.Cfg;
using NHibernate.Criterion;
using NHibernate.Exceptions;
using YoureOnGenNHibernate.Exceptions;
using YoureOnGenNHibernate.EN.YoureOn;
using YoureOnGenNHibernate.CAD.YoureOn;


/*PROTECTED REGION ID(usingYoureOnGenNHibernate.CEN.YoureOn_Usuario_comentar) ENABLED START*/
//  references to other libraries
/*PROTECTED REGION END*/

namespace YoureOnGenNHibernate.CEN.YoureOn
{
public partial class UsuarioCEN
{
public void Comentar (string p_oid)
{
        /*PROTECTED REGION ID(YoureOnGenNHibernate.CEN.YoureOn_Usuario_comentar) ENABLED START*/

        // Write here your custom code...

        throw new NotImplementedException ("Method Comentar() not yet implemented.");

        /*PROTECTED REGION END*/
}
}
}
