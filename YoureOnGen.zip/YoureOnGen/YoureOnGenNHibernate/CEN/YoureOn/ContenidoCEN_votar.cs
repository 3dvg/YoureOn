
using System;
using System.Text;
using System.Collections.Generic;
using NHibernate;
using NHibernate.Cfg;
using NHibernate.Criterion;
using NHibernate.Exceptions;
using YoureOnGenNHibernate.Exceptions;
using YoureOnGenNHibernate.EN.YoureOn;
using YoureOnGenNHibernate.CAD.YoureOn;


/*PROTECTED REGION ID(usingYoureOnGenNHibernate.CEN.YoureOn_Contenido_votar) ENABLED START*/
//  references to other libraries
/*PROTECTED REGION END*/

namespace YoureOnGenNHibernate.CEN.YoureOn
{
public partial class ContenidoCEN
{
public void Votar (string p_oid, float puntos)
{
        /*PROTECTED REGION ID(YoureOnGenNHibernate.CEN.YoureOn_Contenido_votar) ENABLED START*/

        // Write here your custom code...

        throw new NotImplementedException ("Method Votar() not yet implemented.");

        /*PROTECTED REGION END*/
}
}
}
