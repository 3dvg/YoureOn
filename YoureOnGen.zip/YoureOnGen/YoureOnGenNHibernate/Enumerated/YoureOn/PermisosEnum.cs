
using System;

namespace YoureOnGenNHibernate.Enumerated.YoureOn
{
public enum PermisosEnum { moderador=1, administrador=2 };
}
