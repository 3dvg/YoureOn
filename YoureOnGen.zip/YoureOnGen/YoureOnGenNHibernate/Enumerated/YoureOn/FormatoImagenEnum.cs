
using System;

namespace YoureOnGenNHibernate.Enumerated.YoureOn
{
public enum FormatoImagenEnum { jpg=1, png=2, bmp=3 };
}
