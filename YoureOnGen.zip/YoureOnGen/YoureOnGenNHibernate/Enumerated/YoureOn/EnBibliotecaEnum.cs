
using System;

namespace YoureOnGenNHibernate.Enumerated.YoureOn
{
public enum EnBibliotecaEnum { si=1, no=2 };
}
