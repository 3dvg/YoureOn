
using System;

namespace YoureOnGenNHibernate.Enumerated.YoureOn
{
public enum TipoArchivoEnum { texto=1, imagen=2, audio=3, video=4 };
}
