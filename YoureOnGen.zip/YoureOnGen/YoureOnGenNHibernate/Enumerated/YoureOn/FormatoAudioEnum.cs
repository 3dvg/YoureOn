
using System;

namespace YoureOnGenNHibernate.Enumerated.YoureOn
{
public enum FormatoAudioEnum { mp3=1, wav=2, ogg=3 };
}
