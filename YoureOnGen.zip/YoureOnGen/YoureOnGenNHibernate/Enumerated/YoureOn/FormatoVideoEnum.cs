
using System;

namespace YoureOnGenNHibernate.Enumerated.YoureOn
{
public enum FormatoVideoEnum { mp4=1, MPEG=2, avi=3, mov=4 };
}
