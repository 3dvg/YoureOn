
using System;

namespace YoureOnGenNHibernate.Enumerated.YoureOn
{
public enum TipoFaltaEnum { leve=1, grave=2 };
}
